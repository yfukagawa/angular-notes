/* tslint:disable */
/* eslint-disable */
/**
* @param {string} encoded_file
* @returns {string}
*/
export function grayscale(encoded_file: string): string;
