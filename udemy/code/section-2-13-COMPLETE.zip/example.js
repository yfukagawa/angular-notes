function addShipping(price, shipping) {
    return price + shipping;
}
addShipping(10, 5);
