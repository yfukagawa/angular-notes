function addShipping(price: number, shipping: number) : number | boolean {
    return price + shipping;
}

addShipping(10, 5);